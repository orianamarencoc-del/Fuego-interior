Fuego Interior - Tienda (Listo para GitHub Pages)

Archivos:
- index.html : página principal con HTML, CSS y JS integrados.

Cómo publicar en GitHub Pages:
1. Crea un repositorio público en GitHub.
2. Sube (o haz push) el contenido de esta carpeta.
3. En Settings > Pages selecciona branch 'main' y carpeta '/'.
4. Espera unos minutos y abre: https://<tu-usuario>.github.io/<nombre-repo>

Este paquete usa imágenes remotas (CDN). Si quieres, puedo incluir imágenes locales en la carpeta 'assets' en el ZIP.
